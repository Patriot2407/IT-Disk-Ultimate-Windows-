Instructions:

1)Copy alockout.dll to system32 directory on machine sending bad credentials. 

2)Run the appinit.reg script to add the dll to the Appinit_DLL key. 

3)Restart machine

4) wait for account to lockout on that machine

The output (Alockout.LOG) will be created in the winnt\debug directory

 
